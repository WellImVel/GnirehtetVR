@java -jar gnirehtet.jar %*
